from imutils import face_utils
import numpy as np
import argparse
import imutils
import dlib
import cv2
from scipy.spatial import distance
from sklearn import linear_model
from sklearn.metrics import mean_squared_error

# Main function
def main():
  # Import face detector
  detector = dlib.get_frontal_face_detector()
  predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")

  # Get the file names
  files = ["images/" + str(x) + ".pgm" for x in range(1,91)]
  files2 = (["images/" + str(x) + ".jpg" for x in range(91,201)])
  files.extend(files2)


  # Get landmarks for each and every file
  u = 1
  for file in files:
    # Report
    print "Working on: ", file
    # Get image
    image = cv2.imread(file,-1)
    gray = cv2.imread(file,-1)
    # Put image to graysacle
    if u > 90:
      gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Detect faces in the grayscale image
    rects = detector(gray, 1)

    for rect in rects:
      # Get the shapes
      shape = predictor(gray, rect)
      shape = face_utils.shape_to_np(shape)

      # Get face
      (x, y, w, h) = face_utils.rect_to_bb(rect)
      
      cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)

      # Mark landmarks on image
      croped_shape = shape[48:68]
      for (i,(x, y)) in enumerate(shape):
          if i >= 48:
            cv2.circle(image, (x, y), 1, (0, 0, 255), -1)
     
      # Preview
      #cv2.imshow(file,image)
      #cv2.waitKey(0)
      shape = shape.astype(float)
      # Calculate distances for landmarks
      
      # AREA
      area = 0
      points = [shape[61],shape[63],shape[67], shape[65]]
      q = points[-1]
      for p in points:  
        area += p[0] * q[1] - p[1] * q[0]
        q = p
      area = area / 2

      # LINEAR REGRESSION
      x = [shape[48][0],shape[60][0],shape[67][0],shape[66][0],shape[65][0],shape[64][0],shape[54][0],
          shape[61][0],shape[62][0],shape[63][0]]
      y = [shape[48][1],shape[60][1],shape[67][1],shape[66][1],shape[65][1],shape[64][1],shape[54][1],
          shape[61][1],shape[62][1],shape[63][1]]
      
      x = np.asarray(x)
      y = np.asarray(y)

      x = x.reshape(-1,1)
      y = y.reshape(-1,1)
      

      reg=linear_model.LinearRegression()
      reg.fit(x,y)
      predicted_values = [reg.coef_ * i + reg.intercept_ for i in x]
      predicted_values = np.asarray(predicted_values)
      predicted_values = predicted_values.reshape(-1,1)
      mse = mean_squared_error(y, predicted_values)

      # CURVATURE
      x = [shape[48][0],shape[59][0],shape[58][0],shape[57][0],shape[56][0],shape[55][0],shape[54][0]]
      y = [shape[48][1],shape[59][1],shape[58][1],shape[57][1],shape[56][1],shape[55][1],shape[54][1]]
      #x = np.asarray(x).reshape(-1,1)
      #y = np.asarray(y).reshape(-1,1)
      pol1 = np.poly1d(np.polyfit(x, y, 2))
      
      x = [shape[48][0],shape[49][0],shape[50][0],shape[51][0],shape[52][0],shape[53][0],shape[54][0]]
      y = [shape[48][1],shape[49][1],shape[50][1],shape[51][1],shape[52][1],shape[53][1],shape[54][1]]
      pol2 = np.poly1d(np.polyfit(x, y, 2))


      # SOMETHING NEW FOR IKONIC
      x = [shape[48][0],shape[60][0],shape[61][0],shape[67][0]]
      y = [shape[48][1],shape[60][1],shape[61][1],shape[67][1]]
      
      x = np.asarray(x).reshape(-1,1)
      y = np.asarray(y).reshape(-1,1)
     
      x1 = [shape[54][0], shape[64][0], shape[63][0], shape[65][0]]
      y1 = [shape[54][1], shape[64][1], shape[63][1], shape[65][1]]
      x1 = np.asarray(x1).reshape(-1,1)
      y1 = np.asarray(y1).reshape(-1,1)
     

      reg=linear_model.LinearRegression()
      reg.fit(x,y)
      cl = reg.coef_

      reg=linear_model.LinearRegression()
      reg.fit(x1,y1)
      cr = reg.coef_
      
      dec = 0
      if (cl == 1 and cr == 1):
        dec = 1

      if (cl == 0 and cr == 0):
        dec = 2
      
      if (cl == 0 and cr == 1):
        dec = 3
      
      if (cl == 1 and cr == 0):
        dec = 4
      
      # ALL
      scale = distance.euclidean(shape[48], shape[54])
      d1 = distance.euclidean(shape[50], shape[58]) / scale
      d2 = distance.euclidean(shape[51], shape[57]) / scale
      d3 = distance.euclidean(shape[52], shape[56]) / scale
      d4 = distance.euclidean(shape[61], shape[67]) / scale
      d5 = distance.euclidean(shape[62], shape[66]) / scale
      d6 = distance.euclidean(shape[63], shape[65]) / scale
      d7 = distance.euclidean(shape[49], shape[53]) / scale
      d8 = distance.euclidean(shape[60], shape[64]) / scale
      d9 = distance.euclidean(shape[59], shape[55]) / scale

      # Something new
      x = [shape[48][0],shape[60][0],shape[67][0],shape[66][0],shape[65][0],shape[64][0],shape[54][0],
          shape[61][0],shape[62][0],shape[63][0]]
      y = [shape[48][1],shape[60][1],shape[67][1],shape[66][1],shape[65][1],shape[64][1],shape[54][1],
          shape[61][1],shape[62][1],shape[63][1]]
      
     
      pol = np.poly1d(np.polyfit(x, y, 4))
      for i in range(len(pol)):
        if pol[i] < 0:
          pol[i] = -1
        else:
          pol[i] = 1

      with open('features.txt', 'a') as the_file:
        #the_file.write('%f,%f,%f,%f,%f,%f,%f\n' %(d1,d2,d3,d4,d5,d6,d7))
        the_file.write('%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f\n' %(area,mse,pol1[2],pol2[2],dec,d1,d2,d3,d4,d5,d6,d7,d8,d9,pol[0]
          ,pol[1],pol[2],pol[3],pol[4]))
      
# Call main
if __name__=="__main__":
  main()