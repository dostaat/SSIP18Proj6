# Import librearies
import numpy as np
from sklearn.metrics import confusion_matrix
from sklearn.cross_validation import train_test_split
from sklearn.ensemble import RandomForestClassifier


# Get people success
def getSuccessPeople():
  # Get blank space for confusion matrix
  confusionM = np.zeros((4, 4))

  # Get accuracy measurment
  acc = 0
  for i in range(1,8):
    # Get name of file and import data
    name = str(i) + ".csv"
    data = np.genfromtxt(name, delimiter=',')

    # Get statistic accuraccy
    for j in range (0,19):
      if data[0][j] == data[1][j]:
        acc += 1

    # Get conf matrix
    cf = confusion_matrix(data[0], data[1])
    r = cf.sum(axis=0)  
    r = r.astype(float)
    cf = cf.astype(float)
    if r[0] != 0:
      cf[:,0] = cf[:,0] / r[0] * 100
    if r[1] != 0:
      cf[:,1] = cf[:,1] / r[1] * 100
    if r[2] != 0:
      cf[:,2] = cf[:,2] / r[2] * 100
    if r[3] != 0:
      cf[:,3] = cf[:,3] / r[3] * 100
    # Add to general confusion matrix
    confusionM += cf
  
  # Final measurments
  confusionM = confusionM / 7
  print confusionM
  acc = float(acc) / (19*7)
  print acc

def getSuccessMachine():
  # Get trainer
  # Get data
  features = np.genfromtxt("features.txt", delimiter=',')
  labels = np.genfromtxt("labels.csv", delimiter=',')
  
  # Get storage matrix and acc storage  
  confusionM = np.zeros((4, 4))
  accuraccy = 0
  # Play around

  for i in range(100):
    print i
    train_X, test_X, train_Y, test_Y = train_test_split(features,labels,test_size=0.20)
    RF = RandomForestClassifier(n_estimators=100)
    RF.fit(train_X, train_Y)

    # Get features and predictions
    test_X = np.genfromtxt("features2.txt", delimiter=',')
    test_Y = np.genfromtxt("labels2.csv", delimiter=',')

    predictions = RF.predict(test_X)
    # Get conf matrix
    cf = confusion_matrix(test_Y, predictions)
    r = cf.sum(axis=0)  
    r = r.astype(float)
    cf = cf.astype(float)
    if r[0] != 0:
      cf[:,0] = cf[:,0] / r[0] * 100
    if r[1] != 0:
      cf[:,1] = cf[:,1] / r[1] * 100
    if r[2] != 0:
      cf[:,2] = cf[:,2] / r[2] * 100
    if r[3] != 0:
      cf[:,3] = cf[:,3] / r[3] * 100
    # Get accuracy
    acc = RF.score(test_X,test_Y)  
    confusionM += cf
    accuraccy += acc
  
  # Normalize
  r = confusionM.sum(axis=0)  
  r = r.astype(float)
  cf = cf.astype(float)
  if r[0] != 0:
    confusionM[:,0] = confusionM[:,0] / r[0] * 100
  if r[1] != 0:
    confusionM[:,1] = confusionM[:,1] / r[1] * 100
  if r[2] != 0:
    confusionM[:,2] = confusionM[:,2] / r[2] * 100
  if r[3] != 0:
    confusionM[:,3] = confusionM[:,3] / r[3] * 100

  # Print everything
  print confusionM
  print accuraccy / 100

# Define main function
def main():
  # Generate statistics for people
  peopleSuccess = getSuccessPeople()
  machineSuccess = getSuccessMachine()

# Call main function
if __name__ == "__main__":
  main()