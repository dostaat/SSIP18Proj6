from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt

labels = ['Happy', 'Sad', 'Neutral', 'Angry']
cm = [[77.92871076,  9.51674992,  7.83190667,  9.4705267, ],
 [ 7.46371822, 39.05126818, 19.99538447, 21.94220779],
 [ 4.77510416, 25.31840659, 57.4785681,  15.55169553],
 [ 9.83246685, 26.11357531, 14.69414076, 53.03556999]]
print(cm)
fig = plt.figure()
ax = fig.add_subplot(111)
cax = ax.matshow(cm)
plt.title('Confusion matrix - Algorithm peformance Training')
fig.colorbar(cax)
ax.set_xticklabels([''] + labels)
ax.set_yticklabels([''] + labels)
plt.xlabel('Predicted')
plt.ylabel('True')
plt.show()