from imutils import face_utils
import numpy as np
import argparse
import imutils
import dlib
import cv2
import random
import csv

class BoundingBox(object):
    """
    A 2D bounding box
    """
    def __init__(self, points):
        if len(points) == 0:
            raise ValueError("Can't compute bounding box of empty list")
        self.minx, self.miny = float("inf"), float("inf")
        self.maxx, self.maxy = float("-inf"), float("-inf")
        for x, y in points:
            # Set min coords
            if x < self.minx:
                self.minx = x
            if y < self.miny:
                self.miny = y
            # Set max coords
            if x > self.maxx:
                self.maxx = x
            elif y > self.maxy:
                self.maxy = y
    @property
    def width(self):
        return self.maxx - self.minx
    @property
    def height(self):
        return self.maxy - self.miny
    def __repr__(self):
        return "BoundingBox({}, {}, {}, {})".format(
            self.minx, self.maxx, self.miny, self.maxy)
    def cords(self):
      return (self.minx, self.maxx, self.miny, self.maxy)


# Main function
def main():
  # Random seed
  samples = range(1,20)

  # Import face detector
  detector = dlib.get_frontal_face_detector()
  predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")

  # Get labels
  labels = np.genfromtxt("labels.csv", delimiter=',')

  myLabels = []
  userLabels = []
  
  for t in samples:
    myLabels.append(int(labels[t-1]))

  for elem in samples:
    name = str(elem) + ".jpg"  
    # Get frame
    image = cv2.imread(name)

    # Resize image
    image = cv2.resize(image, (0,0), fx=0.25, fy=0.25) 
    
    # Gray image
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Detect faces in the grayscale image
    rects = detector(gray, 1)

    for rect in rects:
      # Get the shapes
      shape = predictor(gray, rect)
      shape = face_utils.shape_to_np(shape)

    # Show frame
    points = np.array(shape[48:67])
    obj = BoundingBox(points)
    x_min,x_max,y_min,y_max = obj.cords()

    x_min -= 10
    x_max += 10
    y_min -= 10
    y_max += 10

    crop_img = image[y_min:y_min+(y_max-y_min), x_min:x_min+(x_max-x_min)]
    crop_img = cv2.resize(crop_img,(0,0), fx=4, fy=4) 
    cv2.imshow(str(elem), crop_img)
    cv2.moveWindow(str(elem), 600,350)
    k = cv2.waitKey(0)
    if k == 49:
      userLabels.append(1)
    if k == 50:
      userLabels.append(2)
    if k == 51:
      userLabels.append(3)
    if k == 52:
      userLabels.append(4)
    cv2.destroyAllWindows()
  
  # Save 
  
  with open("9.csv", 'wb') as myfile:
    wr = csv.writer(myfile)
    wr.writerow(myLabels)
    wr.writerow(userLabels) 
     
  

# Call main
if __name__ == "__main__":
  main()