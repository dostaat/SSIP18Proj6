# Import librearies
import numpy as np
from sklearn.svm import SVC  
from sklearn.neighbors import KNeighborsClassifier
from sklearn import svm
from sklearn import datasets
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import confusion_matrix
from sklearn.cross_validation import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import RandomForestClassifier
import statistics

# Def main function
def main():
  # Get data
  features = np.genfromtxt("features.txt", delimiter=',')
  labels = np.genfromtxt("labels.csv", delimiter=',')
  
  # Vectors
  RF_t = []
  NB_t = []
  DT_t = []
  KNN_t = []
  confusionM = np.zeros((4, 4))
  
  for i in range(100):
    print i
    # Get sets 
    train_X, test_X, train_Y, test_Y = train_test_split(features,labels,test_size=0.20)
  
    # RM Forest
    #*****************************************************************#
    RF = RandomForestClassifier(n_estimators=100)
    RF.fit(train_X, train_Y)
    
    # accuracy on X_test
    #print "RF"
    accuracy = RF.score(train_X, train_Y)
    #print accuracy,
    accuracy = RF.score(test_X, test_Y)
    #print accuracy

    rf_predictions = RF.predict(test_X)
    cf = confusion_matrix(test_Y, rf_predictions)
    r = cf.sum(axis=0)
  
    r = r.astype(float)
    
    cf = cf.astype(float)
    if r[0] != 0:
      cf[:,0] = cf[:,0] / r[0] * 100
    if r[1] != 0:
      cf[:,1] = cf[:,1] / r[1] * 100
    if r[2] != 0:
      cf[:,2] = cf[:,2] / r[2] * 100
    if r[3] != 0:
      cf[:,3] = cf[:,3] / r[3] * 100
    
    confusionM = confusionM + cf    
    RF_t.append(accuracy)
    #*****************************************************************#

    # KNN
    #*****************************************************************#
    #print "KNN"
    knn = KNeighborsClassifier(n_neighbors = 10).fit(train_X, train_Y)
   
    # accuracy on X_test
    accuracy = knn.score(train_X, train_Y)
    #print accuracy,
    accuracy = knn.score(test_X, test_Y)
    #print accuracy

    knn_predictions = knn.predict(test_X)  

    KNN_t.append(accuracy)
    #*****************************************************************#

    # Decission tree
    #*****************************************************************#
    #print "DEC TREE"
    dtree_model = DecisionTreeClassifier(criterion = "gini", max_depth = 20).fit(train_X, train_Y)
    dtree_predictions = dtree_model.predict(test_X)

    # Get accuracy
    accuracy = dtree_model.score(train_X, train_Y)
    #print accuracy,
    accuracy = dtree_model.score(test_X, test_Y)
    #print accuracy

    DT_t.append(accuracy)

    #*****************************************************************#  
    #print "NB"  
    # Naive Bayes
    # training a Naive Bayes classifier

    gnb = GaussianNB().fit(train_X, train_Y)
    gnb_predictions = gnb.predict(test_X)
   
    # accuracy on X_test
    accuracy = gnb.score(train_X, train_Y)
    #print accuracy,
    accuracy = gnb.score(test_X, test_Y)
    #print accuracy
    NB_t.append(accuracy)

  # Creating a confusion matrix and printing statistics
  print "RF"
  print "Mean:", np.mean(RF_t)
  print "Median:", np.median(RF_t)
  print "Median difference:", np.percentile(RF_t,75) - np.percentile(RF_t,25)
  print "STD:", np.std(RF_t)
  print "----------------------------------"
  print "DT"
  print "Mean:", np.mean(DT_t)
  print "Median:", np.median(DT_t)
  print "Median difference:", np.percentile(DT_t,75) - np.percentile(DT_t,25)
  print "STD:", np.std(DT_t)
  print "----------------------------------"
  print "KNN"
  print "Mean:", np.mean(KNN_t)
  print "Median:", np.median(KNN_t)
  print "Median difference:", np.percentile(KNN_t,75) - np.percentile(KNN_t,25)
  print "STD:", np.std(DT_t)
  print "----------------------------------"
  print "NB"
  print "Mean:", np.mean(NB_t)
  print "Median:", np.median(NB_t)
  print "Median difference:", np.percentile(NB_t,75) - np.percentile(NB_t,25)
  print "STD:", np.std(NB_t)
  print "----------------------------------"

  print confusionM/100

# Call main function
if __name__== "__main__":
  main()